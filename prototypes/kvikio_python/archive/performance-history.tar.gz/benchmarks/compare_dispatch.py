# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Isolate dispatch changes using the same process, file, allocation, and pool.

Only the preserved _parallel method is substituted. This diagnostic does not
represent a full historical backend; fresh-process comparisons cover that.
"""

import argparse
import ast
import hashlib
import json
import statistics
import tempfile
import time
from contextlib import ExitStack, nullcontext
from pathlib import Path
from unittest.mock import patch

from compare_optimizations import audit


def preserved_dispatch(path, backend):
    source = path.read_bytes()
    module = ast.parse(source, filename=str(path))
    cls = next(node for node in module.body if isinstance(node, ast.ClassDef) and node.name == "CuFile")
    function = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "_parallel")
    namespace = vars(backend).copy()
    # Execute only the selected method from the trusted, archived local source.
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(path), "exec"), namespace)  # noqa: S102
    return namespace["_parallel"], hashlib.sha256(source).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", type=Path, required=True)
    parser.add_argument("--regressed", type=Path, required=True)
    parser.add_argument("--directory", default="/mnt/nvme0")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--probe-context", action="store_true")
    parser.add_argument(
        "--strided", type=Path, help="Preserved grouped/interleaved file_handle.py for diagnostic probes"
    )
    args = parser.parse_args()
    if args.probe_context and args.strided is None:
        parser.error("--probe-context requires --strided from the pre-contiguous-dispatch archive")
    import cupy as cp
    import numpy as np

    import cufile_python as api
    from cufile_python._lib import file_handle

    original, original_hash = preserved_dispatch(args.original, file_handle)
    regressed, regressed_hash = preserved_dispatch(args.regressed, file_handle)
    variants = {"original": original, "regressed": regressed, "fixed": file_handle.CuFile._parallel}
    chunks = file_handle.CuFile._transfer_chunks

    def context_once(self, arr, size, file_offset, first, stride, task_size, write, context, compat, finish):
        with context:
            return chunks(self, arr, size, file_offset, first, stride, task_size, write, nullcontext(), compat, finish)

    def contiguous(self, arr, size, file_offset, first, stride, task_size, write, context, compat, finish):
        workers = stride // task_size
        chunk_count = (size + task_size - 1) // task_size
        index = first // task_size
        begin = (index * chunk_count // workers) * task_size
        end = min(size, ((index + 1) * chunk_count // workers) * task_size)
        return chunks(self, arr, end, file_offset, begin, task_size, task_size, write, context, compat, finish)

    strided_hash = None
    if args.strided is not None:
        strided, strided_hash = preserved_dispatch(args.strided, file_handle)
        variants["strided"] = strided
        if args.probe_context:
            variants.update(context_once=strided, contiguous=strided)
    report = {
        "method": __doc__,
        "source_hashes": {
            "original": original_hash,
            "regressed": regressed_hash,
            "fixed": hashlib.sha256(Path(file_handle.__file__).read_bytes()).hexdigest(),
            "strided": strided_hash,
            "harness": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        },
        "settings": "64 MiB, four workers, 4 MiB tasks, threshold zero, cuFile selected, no monitor",
        "audits": [audit()],
        "rows": [],
    }
    with ExitStack() as stack:
        directory = Path(stack.enter_context(tempfile.TemporaryDirectory(dir=args.directory)))
        expected = np.arange(64 * 1024**2, dtype=np.uint8)
        path = directory / "data"
        path.write_bytes(expected.tobytes())
        target = cp.empty(expected.size, dtype=cp.uint8)
        cp.cuda.get_current_stream().synchronize()
        stack.enter_context(api.defaults.set({"compat_mode": api.CompatMode.OFF, "num_threads": 4, "gds_threshold": 0}))
        file = stack.enter_context(api.CuFile(path))
        order = list(variants)
        for round_index in range(6):
            for name in order:
                with (
                    patch.object(file_handle.CuFile, "_parallel", variants[name]),
                    patch.object(
                        file_handle.CuFile,
                        "_transfer_chunks",
                        context_once if name == "context_once" else contiguous if name == "contiguous" else chunks,
                    ),
                ):
                    for _ in range(10):
                        assert file.read(target) == target.nbytes
                    for cache, samples in (("warm", 150), ("file-cache-evicted", 30)):
                        timings = []
                        for _ in range(samples):
                            if cache != "warm":
                                api.drop_file_page_cache(path)
                                assert api.get_page_cache_info(path)[0] == 0
                            begin = time.perf_counter_ns()
                            assert file.read(target) == target.nbytes
                            timings.append((time.perf_counter_ns() - begin) / 1000)
                        report["rows"].append(
                            {
                                "round": round_index + 1,
                                "variant": name,
                                "cache": cache,
                                "median_us": statistics.median(timings),
                                "samples_us": timings,
                            }
                        )
                        np.testing.assert_array_equal(cp.asnumpy(target), expected)
            order = order[-1:] + order[:-1]
    report["audits"].append(audit())
    report["summary"] = {
        cache: {
            name: statistics.median(
                r["median_us"] for r in report["rows"] if r["cache"] == cache and r["variant"] == name
            )
            for name in variants
        }
        for cache in ("warm", "file-cache-evicted")
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
