# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Compare a preserved Python backend, the current backend, and reference KvikIO."""

import argparse
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path


def audit():
    ps = shutil.which("ps")
    nvidia_smi = shutil.which("nvidia-smi")
    if ps is None or nvidia_smi is None:
        raise RuntimeError("The benchmark audit requires ps and nvidia-smi")
    processes = subprocess.check_output([ps, "-eo", "pid=,comm="], text=True)
    return {
        "utc": datetime.now(UTC).isoformat(),
        "gpu": subprocess.check_output(
            [nvidia_smi, "--query-gpu=name,utilization.gpu,utilization.memory,memory.used", "--format=csv,noheader"],
            text=True,
        ).strip(),
        "gpu_processes": subprocess.check_output(
            [nvidia_smi, "--query-compute-apps=pid,process_name,used_gpu_memory", "--format=csv,noheader"],
            text=True,
        ).strip(),
        "io_processes": [
            line.strip() for line in processes.splitlines() if line.split()[-1] in {"gdsio", "fio", "gdsio_verify"}
        ],
    }


def hashes(root):
    return {
        str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted((root / package_name(root)).rglob("*.py"))
    }


def package_name(root):
    for name in ("cufile_python", "kvikio"):
        if (root / name / "_lib/file_handle.py").is_file():
            return name
    raise ValueError(f"No Python cuFile backend found under {root}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before", type=Path, required=True)
    parser.add_argument("--directory", default="/mnt/nvme0")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--large-read", action="store_true")
    args = parser.parse_args()
    if args.rounds < 1:
        parser.error("--rounds must be positive")
    root = Path(__file__).resolve().parents[1]
    before = args.before.resolve()
    if before == root:
        parser.error("--before must be a separate preserved Python backend")
    before_package = package_name(before)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    records = {name: [] for name in ("before", "after", "reference")}
    report = {
        "method": "Identical workloads in fresh processes; rotate implementation order across rounds; no profiler",
        "workload": "64 MiB/four-worker cuFile read: 300 warm and 30 cache-evicted samples per run"
        if args.large_read
        else "54-case local I/O matrix",
        "settings": "task_size=4 MiB, gds_threshold=0, direct read off, direct write on, no statistics monitor",
        "source_hashes": {"before": hashes(before), "after": hashes(root)},
        "environment": {
            k: os.environ[k]
            for k in ("CUDA_VISIBLE_DEVICES", "CUFILE_ENV_PATH_JSON", "CUFILE_LOGGING_LEVEL")
            if k in os.environ
        },
        "audits": [audit()],
        "runs": [],
    }
    order = ["before", "after", "reference"]
    for round_index in range(args.rounds):
        for name in order:
            target = output.with_name(f"{output.stem}-{round_index + 1}-{name}.json")
            env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH" and not k.startswith("KVIKIO_")}
            if name != "reference":
                env["PYTHONPATH"] = str(before if name == "before" else root)
            print(f"Round {round_index + 1}/{args.rounds}: {name}", flush=True)
            started = time.monotonic()
            completed = subprocess.run(
                [
                    sys.executable,
                    str(root / "benchmarks/compare.py"),
                    "--worker",
                    "reference" if name == "reference" else "python",
                    "--package",
                    "kvikio" if name == "reference" else before_package if name == "before" else package_name(root),
                    "--directory",
                    args.directory,
                    "--output",
                    str(target),
                    *(["--large-read"] if args.large_read else []),
                ],
                env=env,
                cwd="/tmp",
                capture_output=True,
                text=True,
                timeout=300,
            )
            target.with_suffix(".log").write_text(completed.stdout + completed.stderr)
            completed.check_returncode()
            result = json.loads(target.read_text())
            if result["libkvikio_loaded"] != (name == "reference"):
                raise AssertionError(f"Wrong native backend loaded: {name}")
            if name != "reference":
                expected_root = before if name == "before" else root
                if not Path(result["package"]).is_relative_to(expected_root):
                    raise AssertionError(f"Wrong Python backend loaded: {name}")
            records[name].append(result)
            report["runs"].append(
                {
                    "round": round_index + 1,
                    "implementation": name,
                    "elapsed_seconds": time.monotonic() - started,
                    "path": target.name,
                }
            )
            report["audits"].append(audit())
            print(f"  {len(result['rows'])} cases passed payload checks", flush=True)
        order = order[-1:] + order[:-1]

    fields = ("mode", "memory", "size", "threads", "api", "cache")

    def key(row):
        return tuple(row[field] for field in fields)

    indexed = {name: [{key(row): row for row in run["rows"]} for run in runs] for name, runs in records.items()}
    expected = set(indexed["before"][0])
    if any(set(run) != expected for runs in indexed.values() for run in runs):
        raise AssertionError("Benchmark cases differ between runs")
    rows = []
    for identity in sorted(expected):
        row = dict(zip(fields, identity))
        for name, runs in indexed.items():
            row[name] = {
                field: statistics.median(run[identity][field] for run in runs)
                for field in ("median_us", "p95_us", "gib_per_s")
            }
            row[name]["run_median_us"] = [run[identity]["median_us"] for run in runs]
        row["latency_reduction_percent"] = (1 - row["after"]["median_us"] / row["before"]["median_us"]) * 100
        row["after_vs_reference_percent"] = (row["after"]["median_us"] / row["reference"]["median_us"] - 1) * 100
        rows.append(row)
    report["rows"] = rows
    if hashes(before) != report["source_hashes"]["before"] or hashes(root) != report["source_hashes"]["after"]:
        raise RuntimeError("A backend changed during measurement")
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(output)


if __name__ == "__main__":
    main()
