# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Local I/O attribution probes; experimental substitutions exist only in this process."""

import argparse
import json
import statistics
import tempfile
import time
from concurrent.futures import Future, ThreadPoolExecutor
from contextlib import ExitStack
from functools import partial
from pathlib import Path
from unittest.mock import patch


def measure(call, count):
    for _ in range(10):
        call()
    samples = []
    for _ in range(count):
        start = time.perf_counter_ns()
        call()
        samples.append(time.perf_counter_ns() - start)
    return statistics.median(samples) / 1000


def noop(*args):
    pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", default="/mnt/nvme0")
    parser.add_argument("--output", required=True)
    parser.add_argument("--reference", action="store_true")
    parser.add_argument("--only", nargs="+")
    parser.add_argument("--skip-profile", action="store_true")
    args = parser.parse_args()

    import cupy as cp
    import numpy as np

    if args.reference:
        import kvikio
        import kvikio.defaults
    else:
        import cufile_python as kvikio
        import cufile_python.defaults

    report = {"package": kvikio.__file__, "cases": [], "profiles": [], "components": {}}
    if not args.reference:
        import yappi

        from cufile_python._lib import _runtime, arr, buffer, file_handle, future
        from cufile_python._lib import statistics as stats

        if stats._monitors:
            raise RuntimeError("These probes require statistics monitoring to be disabled")

        def single_future(futures=(), *, finish=None, value=0):
            if len(futures) != 1:
                return future.IOFuture(futures, finish=finish, value=value)
            result = object.__new__(future.IOFuture)
            result.future, result._used = futures[0], False

            def done(task):
                error = task.exception()
                finish(0 if error else task.result(), error)

            if finish is not None:
                futures[0].add_done_callback(done)
            return result

    with tempfile.TemporaryDirectory(prefix="kvikio-local-profile-", dir=args.directory) as temporary:
        for size in (4096, 64 * 1024**2):
            expected = np.arange(size, dtype=np.uint8)
            path = Path(temporary) / "data"
            path.write_bytes(expected.tobytes())
            target = cp.empty(size, dtype=cp.uint8)
            cp.cuda.get_current_stream().synchronize()
            for mode in (kvikio.CompatMode.ON, kvikio.CompatMode.OFF):
                with (
                    kvikio.defaults.set(
                        {"compat_mode": mode, "num_threads": 1, "gds_threshold": 0, "task_size": 4 * 1024**2}
                    ),
                    kvikio.CuFile(path, "r") as file,
                ):
                    calls = {"original": partial(file.read, target), "raw_read": partial(file.raw_read, target)}
                    if not args.reference:
                        view = arr.Array(target)
                        context = _runtime.Context(view)

                        class CachedContext(_runtime.Context):
                            def __init__(self, _array, handle=context.context):
                                self.context = handle

                        calls.update(
                            dict.fromkeys(
                                ("cached_context", "no_monitor_overhead", "single_future", "combined"),
                                calls["original"],
                            )
                        )
                        calls["prepared_view"] = partial(file.read, view)

                        def chunk_loop(
                            handle=file._handle, view=view, count=size, ctx=context, compat=mode == kvikio.CompatMode.ON
                        ):
                            return sum(
                                handle._transfer(
                                    view, min(4 * 1024**2, count - offset), offset, offset, False, ctx, compat
                                )
                                for offset in range(0, count, 4 * 1024**2)
                            )

                        def single_job(run=chunk_loop, ctx=context):
                            with ctx:
                                _runtime.cuda(_runtime.driver.cuStreamSynchronize(0))
                            return _runtime.pool().submit(run).result()

                        calls["one_worker_chunk_loop"] = single_job
                        if mode == kvikio.CompatMode.OFF:
                            allocation, capacity = _runtime.cuda(_runtime.driver.cuMemGetAddressRange(view.ptr))
                            allocation = int(allocation)

                            def stable_pointer(ptr, base=allocation, capacity=capacity):
                                if not base <= ptr < base + capacity:
                                    raise ValueError("Pointer outside diagnostic allocation")
                                return base, ptr - base

                            calls["native_allocation_base"] = calls["original"]
                            calls["bindings_direct"] = partial(
                                _runtime.cufile.read, file._handle._handle, view.ptr, size, 0, 0
                            )
                    if args.only:
                        calls = {name: call for name, call in calls.items() if name in args.only}
                    rounds = {name: [] for name in calls}
                    for iteration in range(4):
                        order = list(calls) if iteration % 2 == 0 else list(reversed(calls))
                        for name in order:
                            with ExitStack() as stack:
                                if name == "native_allocation_base":
                                    stack.enter_context(patch.object(buffer, "registered_pointer", stable_pointer))
                                if name in ("cached_context", "combined"):
                                    stack.enter_context(patch.object(file_handle, "Context", CachedContext))
                                if name in ("no_monitor_overhead", "combined"):
                                    stack.enter_context(patch.object(stats, "observe", lambda *_args: None))
                                if name in ("single_future", "combined"):
                                    stack.enter_context(patch.object(file_handle, "IOFuture", single_future))
                                rounds[name].append(measure(calls[name], 400 if size == 4096 else 20))
                                np.testing.assert_array_equal(cp.asnumpy(target), expected)
                    report["cases"].append({"mode": mode.name, "size": size, "round_median_us": rounds})
                    print(
                        mode.name, size, {key: round(statistics.median(v), 2) for key, v in rounds.items()}, flush=True
                    )

                    if not args.reference and not args.skip_profile and size == 4096:
                        for clock in ("wall", "cpu"):
                            yappi.clear_stats()
                            yappi.set_clock_type(clock)
                            yappi.start(builtins=True, profile_threads=True)
                            for _ in range(300):
                                file.read(target)
                            yappi.stop()
                            functions = [
                                {
                                    "name": f.name,
                                    "module": f.module,
                                    "line": f.lineno,
                                    "calls_per_op": f.ncall / 300,
                                    "inclusive_us_per_op": f.ttot * 1e6 / 300,
                                    "self_us_per_op": f.tsub * 1e6 / 300,
                                }
                                for f in yappi.get_func_stats()
                            ]
                            report["profiles"].append({"mode": mode.name, "clock": clock, "functions": functions})
                        yappi.clear_stats()
            if not args.reference and not args.skip_profile and size == 4096:
                view = arr.Array(target)
                context = _runtime.Context(view)

                def scope(ctx=context):
                    with ctx:
                        pass

                ready = Future()
                ready.set_result(size)

                def disabled_observation(count=size):
                    finish = stats.observe(count, False, "gds")
                    if finish is not None:
                        finish(count, None)

                components = {
                    "array_view": partial(arr.Array, target),
                    "context_lookup": partial(_runtime.Context, view),
                    "context_push_pop": scope,
                    "stream_sync_idle": lambda: _runtime.cuda(_runtime.driver.cuStreamSynchronize(0)),
                    "ready_future_wrapper": lambda _ready=ready: future.IOFuture([_ready]).get(),
                    "disabled_observation": disabled_observation,
                }
                with ThreadPoolExecutor(max_workers=1) as executor:
                    components["empty_task_roundtrip"] = lambda: executor.submit(noop).result()
                    report["components"] = {name: measure(call, 1500) for name, call in components.items()}
    report["libkvikio_loaded"] = "libkvikio.so" in Path("/proc/self/maps").read_text()
    Path(args.output).write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
