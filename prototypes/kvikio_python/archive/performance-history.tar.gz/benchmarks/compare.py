# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Run the identical workload in isolated reference and Python-backend processes.

python benchmarks/compare.py --directory /mnt/nvme0 --output benchmarks/results.json
The reference KvikIO wheel and this prototype must never share a process.
"""

import argparse
import importlib
import importlib.metadata
import json
import os
import platform
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path


def worker(args):
    import cupy as cp
    import numpy as np

    package = args.package or ("kvikio" if args.worker == "reference" else "cufile_python")
    kvikio = importlib.import_module(package)
    importlib.import_module(package + ".cufile_driver")
    importlib.import_module(package + ".defaults")
    native_only = package == "cufile_python" and not hasattr(
        importlib.import_module(package + "._lib.file_handle"), "_posix"
    )

    rows = []
    with tempfile.TemporaryDirectory(prefix="kvikio-compare-", dir=args.directory) as directory:
        path = Path(directory) / "data.bin"
        stream = cp.cuda.Stream()
        for mode in ("OFF",) if args.large_read else ("ON", "OFF"):
            for size in (64 * 1024**2,) if args.large_read else (4096, 1024**2, 64 * 1024**2):
                source = cp.arange(size, dtype=cp.uint8)
                expected = cp.asnumpy(source)
                for memory in ("device",) if args.large_read else ("host", "device"):
                    route = "cufile" if native_only or (memory == "device" and mode == "OFF") else "posix"
                    if memory == "host" and mode == "OFF":
                        continue
                    buf = np.empty(size, dtype=np.uint8) if memory == "host" else cp.empty_like(source)
                    for threads in (4,) if args.large_read else (1, 4):
                        config = {
                            "compat_mode": getattr(kvikio.CompatMode, mode),
                            "num_threads": threads,
                            "gds_threshold": 0,
                            "task_size": 4 * 1024**2,
                            "auto_direct_io_read": False,
                            "auto_direct_io_write": True,
                        }
                        with kvikio.defaults.set(config):
                            path.write_bytes(expected.tobytes())
                            with kvikio.CuFile(path, "r+") as file:
                                apis = (
                                    ("read", "write")
                                    if memory == "host" or threads == 4
                                    else ("read", "write", "raw_read", "raw_read_async")
                                )
                                if args.large_read:
                                    apis = ("read",)
                                for api in apis:
                                    call = getattr(file, api)

                                    def operation(call=call, buf=buf, api=api, size=size):
                                        value = (
                                            call(buf, stream.ptr).check_bytes_done()
                                            if api == "raw_read_async"
                                            else call(buf)
                                        )
                                        if value != size:
                                            raise AssertionError(f"{api}: {value} bytes, expected {size}")

                                    if api == "write":
                                        buf[:] = np.asarray(expected) if memory == "host" else source
                                    operation()
                                    cp.cuda.get_current_stream().synchronize()
                                    if api != "write":
                                        np.testing.assert_array_equal(
                                            buf if memory == "host" else cp.asnumpy(buf), expected
                                        )
                                    iterations = 150 if size == 4096 else 40 if size == 1024**2 else 8
                                    if args.large_read:
                                        iterations = 100
                                    timings, totals, cpu = [], [], []
                                    for _ in range(3):
                                        start_cpu = time.process_time_ns()
                                        start = time.perf_counter_ns()
                                        for _ in range(iterations):
                                            begin = time.perf_counter_ns()
                                            operation()
                                            timings.append(time.perf_counter_ns() - begin)
                                        totals.append(time.perf_counter_ns() - start)
                                        cpu.append(time.process_time_ns() - start_cpu)
                                    os.fdatasync(file.fileno())
                                    if api == "write" and path.read_bytes() != expected.tobytes():
                                        raise AssertionError("Written contents differ")
                                    rows.append(
                                        dict(
                                            mode=mode,
                                            selected_api_route=route,
                                            memory=memory,
                                            size=size,
                                            threads=threads,
                                            api=api,
                                            cache="warm",
                                            samples=len(timings),
                                            median_us=statistics.median(timings) / 1e3,
                                            p95_us=sorted(timings)[int(0.95 * len(timings)) - 1] / 1e3,
                                            gib_per_s=size * iterations / statistics.median(totals) * 1e9 / 2**30,
                                            cpu_ms=statistics.median(cpu) / 1e6,
                                            round_ns=totals,
                                        )
                                    )
                                if size == 64 * 1024**2:
                                    timings = []
                                    residency = []
                                    for _ in range(30 if args.large_read else 5):
                                        kvikio.drop_file_page_cache(path)
                                        residency.append(kvikio.get_page_cache_info(path)[0])
                                        start = time.perf_counter_ns()
                                        assert file.read(buf) == size
                                        timings.append(time.perf_counter_ns() - start)
                                    np.testing.assert_array_equal(
                                        buf if memory == "host" else cp.asnumpy(buf), expected
                                    )
                                    rows.append(
                                        dict(
                                            mode=mode,
                                            selected_api_route=route,
                                            memory=memory,
                                            size=size,
                                            threads=threads,
                                            api="read",
                                            cache="file-cache-evicted",
                                            samples=len(timings),
                                            median_us=statistics.median(timings) / 1e3,
                                            p95_us=max(timings) / 1e3,
                                            gib_per_s=size / statistics.median(timings) * 1e9 / 2**30,
                                            resident_pages_before=residency,
                                            round_ns=timings,
                                        )
                                    )
    maps = Path("/proc/self/maps").read_text()
    report = dict(
        implementation=args.worker,
        package=str(Path(kvikio.__file__).resolve()),
        version=kvikio.__version__,
        python=platform.python_version(),
        kernel=platform.release(),
        gpu=cp.cuda.runtime.getDeviceProperties(0)["name"].decode(),
        driver=cp.cuda.runtime.driverGetVersion(),
        libcufile=kvikio.cufile_driver.libcufile_version(),
        bindings=importlib.metadata.version("cuda-bindings"),
        libkvikio_loaded="libkvikio.so" in maps,
        requires_cufile=native_only,
        routing_note=(
            "Legacy compat/threshold/direct-I/O settings do not affect this backend; all I/O calls cuFile."
            if native_only
            else "KvikIO-style POSIX/cuFile selection; cuFile may itself use native compatibility I/O."
        ),
        settings="task_size=4 MiB; gds_threshold=0; direct read off; direct write on",
        rows=rows,
    )
    Path(args.output).write_text(json.dumps(report, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", default="/mnt/nvme0")
    parser.add_argument("--output", required=True)
    parser.add_argument("--worker", choices=["reference", "python"])
    parser.add_argument("--package", choices=["kvikio", "cufile_python"])
    parser.add_argument("--order", choices=["reference-first", "python-first"], default="reference-first")
    parser.add_argument("--large-read", action="store_true", help="Repeat only the 64 MiB, four-worker cuFile read")
    args = parser.parse_args()
    if args.worker:
        worker(args)
        return
    root = Path(__file__).resolve().parents[1]
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    reports = {}
    order = ("reference", "python") if args.order == "reference-first" else ("python", "reference")
    for name in order:
        target = output.with_name(output.stem + "-" + name + ".json")
        env = dict(os.environ)
        env.pop("PYTHONPATH", None)
        if name == "python":
            env["PYTHONPATH"] = str(root)
        subprocess.run(
            [
                sys.executable,
                str(Path(__file__).resolve()),
                "--worker",
                name,
                "--directory",
                args.directory,
                "--output",
                str(target),
                *(["--large-read"] if args.large_read else []),
            ],
            env=env,
            check=True,
            cwd="/tmp",
        )
        reports[name] = json.loads(target.read_text())
    assert reports["reference"]["libkvikio_loaded"]
    assert not reports["python"]["libkvikio_loaded"]
    output.write_text(json.dumps(reports, indent=2) + "\n")
    print(output)


if __name__ == "__main__":
    main()
