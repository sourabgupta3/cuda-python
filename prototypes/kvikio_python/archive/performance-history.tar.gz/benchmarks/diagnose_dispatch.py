# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Measure dispatch separately from an instrumented timeline of the same I/O."""

import argparse
import importlib
import json
import statistics
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", default="kvikio")
    parser.add_argument("--directory", default="/mnt/nvme0")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--variants", nargs="+", choices=["current", "requery"], default=["current", "requery"])
    args = parser.parse_args()
    import cupy as cp
    import numpy as np

    api = importlib.import_module(args.package)
    defaults = importlib.import_module(args.package + ".defaults")
    runtime = importlib.import_module(args.package + "._lib._runtime")
    backend = importlib.import_module(args.package + "._lib.file_handle")
    submit = ThreadPoolExecutor.submit
    native = backend.native
    trace = None
    started = 0
    variant = "current"

    def stamp(kind, offset=-1):
        if trace is not None:
            trace.append([time.perf_counter_ns() - started, kind, offset, threading.get_ident()])

    def dispatch(executor, fn, *params, **kwargs):
        if variant == "requery" and getattr(fn, "__name__", None) == "_transfer":
            # Restore only the removed context query, without changing I/O or futures.
            params = (*params[:5], runtime.Context(params[0]), *params[6:])
        if trace is None:
            return submit(executor, fn, *params, **kwargs)
        stamp("submit")

        def run():
            stamp("worker_start")
            try:
                return fn(*params, **kwargs)
            finally:
                stamp("worker_end")

        return submit(executor, run)

    def traced_native(name, *params):
        if name != "read":
            return native(name, *params)
        stamp("native_start", params[3])
        try:
            return native(name, *params)
        finally:
            stamp("native_end", params[3])

    report = {"package": api.__file__, "round_median_us": {v: [] for v in args.variants}, "traces": {}}
    with tempfile.TemporaryDirectory(dir=args.directory) as directory:
        path = Path(directory) / "data"
        expected = np.arange(64 * 1024**2, dtype=np.uint8)
        path.write_bytes(expected.tobytes())
        target = cp.empty(expected.size, dtype=cp.uint8)
        cp.cuda.get_current_stream().synchronize()
        with (
            defaults.set(
                {"compat_mode": api.CompatMode.OFF, "num_threads": 4, "task_size": 4 * 1024**2, "gds_threshold": 0}
            ),
            api.CuFile(path) as file,
            patch.object(ThreadPoolExecutor, "submit", dispatch),
        ):
            for round_index in range(4):
                order = args.variants if round_index % 2 == 0 else list(reversed(args.variants))
                for variant in order:
                    for _ in range(10):
                        assert file.read(target) == target.nbytes
                    samples = []
                    for _ in range(120):
                        begin = time.perf_counter_ns()
                        assert file.read(target) == target.nbytes
                        samples.append((time.perf_counter_ns() - begin) / 1000)
                    report["round_median_us"][variant].append(statistics.median(samples))
                    np.testing.assert_array_equal(cp.asnumpy(target), expected)
            with patch.object(backend, "native", traced_native):
                for variant in args.variants:
                    traces = []
                    for _ in range(30):
                        trace = []
                        started = time.perf_counter_ns()
                        pending = file.pread(target)
                        stamp("submission_return")
                        assert pending.get() == target.nbytes
                        stamp("result_return")
                        traces.append(trace)
                        trace = None
                    report["traces"][variant] = traces
    report["trace_summary"] = {}
    for variant, traces in report["traces"].items():
        report["trace_summary"][variant] = {
            "median_first_native_us": statistics.median(next(e[0] for e in t if e[1] == "native_start") for t in traces)
            / 1000,
            "median_submission_us": statistics.median(
                next(e[0] for e in t if e[1] == "submission_return") for t in traces
            )
            / 1000,
            "median_jobs": statistics.median(sum(e[1] == "submit" for e in t) for t in traces),
            "median_native_calls": statistics.median(sum(e[1] == "native_start" for e in t) for t in traces),
        }
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "traces"}, indent=2))


if __name__ == "__main__":
    main()
