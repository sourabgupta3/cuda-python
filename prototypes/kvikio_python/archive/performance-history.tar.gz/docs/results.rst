Validation and measured performance
===================================

This report preserves historical measurements and validation from before the
Python POSIX fallback was removed. Current required-cuFile validation is recorded
in ``docs/validation/required-cufile-*``; no current performance is claimed here.
The table below preserves the initial performance measurements. For later
before/after results following the Python overhead and dispatch fixes, see
``docs/optimizations.rst`` and ``benchmarks/contiguous-results.json``.

Environment and method
----------------------

Reference: KvikIO 26.10.00 wheel. Python backend: this source prototype.
Python 3.12.3, CUDA bindings 13.4.4, native cuFile 1.19, H200 NVL,
Linux x86_64, driver API version 13030, files under /mnt/nvme0.
GDS platform verification reported NVMe through nvfs and a supported GPU.
The comparison identifies the selected API path; it does not trace each
request's physical storage route.

The local matrix contains 54 cases per implementation: 4 KiB, 1 MiB, and
64 MiB; host/device memory; one/four workers; compatibility/native cuFile;
blocking read/write, raw read, and stream read plus completion. Task size is
4 MiB, GDS threshold zero, direct reads off, and direct writes on. A warm-up
and payload check precede each case. Warm cases have three rounds of
150/40/8 iterations for the three sizes. File-cache-evicted reads have five
samples; recorded residency is zero before every such read. File flushing
is outside timed writes, so these are completion timings, not durability
measurements. Only private benchmark files are evicted or removed.

The two process runs reverse implementation order. Values shown average
the two per-run medians/throughput results. Raw JSON includes all rounds,
p95 latency, and process CPU time; comparison.csv includes all 54 cases.
No CPU affinity or statistical confidence interval is claimed.

Local GPU results
-----------------

.. list-table:: Selected local cases
   :header-rows: 1
   :widths: 64 18 18

   * - Workload
     - KvikIO
     - Python backend
   * - 4 KiB GPU read, compatibility, 1 worker (us)
     - 48.4
     - 99.8
   * - 4 KiB GPU read, cuFile, 1 worker (us)
     - 98.1
     - 142.5
   * - 4 KiB native stream read + completion (us)
     - 224.3
     - 256.7
   * - 64 MiB GPU read, compatibility, file cache evicted (GiB/s)
     - 5.22
     - 4.92
   * - 64 MiB GPU read, cuFile, 1 worker (GiB/s)
     - 9.82
     - 8.37
   * - 64 MiB GPU read, cuFile, 4 workers (GiB/s)
     - 11.84
     - 12.74
   * - 64 MiB GPU read, cuFile, 4 workers, file cache evicted (GiB/s)
     - 13.08
     - 13.12

Small requests expose Python scheduling, validation, context, and future
overhead. Larger transfers amortize those costs. Four-worker cuFile reads
are close in this experiment; one-worker results still show a cost. These
results do not establish that either implementation is faster generally.

These measurements predate the scope cleanup. Another GDS workload was
observed during profiling; exclusive GPU/storage access was not verified.
Exact percentages remain preliminary pending a quiet rerun. See
``docs/profiling.rst`` for the local overhead investigation.

Validation
----------

* 67 matching public declarations in the selected CuFile/supporting modules;
  no missing/changed/added signatures in that subset.
* Selected upstream local suites with cuFile selected (OFF): 1,001 passed,
  12 skipped, 7 remote-setting tests deselected.
* The same suites with compatibility mode selected (ON): 999 passed,
  14 skipped, 7 deselected. These overlap the OFF cases, not unique extra tests.
* Additional ownership, lifetime, compatibility, and dependency-isolation tests:
  28 passed, including chunk failure draining, bounds, import aliases, and
  compatibility-mode buffer registration. Suites were rerun after that correction.
* porting_demo.py runs using the cufile_python import alias.
* Ten unchanged upstream application runs cover hello_world.py and
  single_node_io.py across both implementations; output hashes match.
* Recorded process mappings confirm libkvikio.so loads in the reference
  benchmark and does not load in the Python benchmark.

This evidence concerns local file I/O, not the complete KvikIO package.
Multiple GPUs, other platforms, and free-threaded Python require additional
qualification. Summary formatting differs, while structured statistics and
binary exchange are tested. The serialized summary retains the original
schema with zero values for excluded backends in locally collected results.

Reproduction and evidence
-------------------------

See README.rst for exact commands. The benchmark scripts retain raw results
in benchmarks/results*.json. Run
benchmarks/report.py after remeasurement to regenerate the comparison table.
docs/validation contains the test summaries, selected native platform output,
and version provenance. Tests on private files do not validate the privileged
system-wide page-cache-drop helper; that helper was not invoked.
