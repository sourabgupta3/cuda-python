Performance attribution
=======================

These profiles predate removal of the Python fallback. Current code requires
cuFile; the POSIX/staging measurements below are historical, not an active path.

This report preserves the initial diagnostic experiments on the H200/NVMe
setup. At that stage, substitutions were confined to benchmark processes.
Context reuse, disabled-monitor bypass, and the single-task future shortcut
are now implemented. See ``docs/optimizations.rst`` for the new before/after
measurements and correctness checks; the timings below are historical.

Method
------

Local cases use one worker, 4 MiB tasks, and GDS threshold zero to exercise
the worker path even at 4 KiB. Four rounds alternate probe order; each round
has 400 small reads or 20 large reads after warm-up. The numbers below are
medians of the round medians. Every probe verifies the resulting data.

Yappi 1.7.6 captures wall-clock and CPU call trees across threads in separate
runs. Profiling materially slows these small operations, so its timings are
not treated as production latencies or added together across threads. The
latency comparisons use runs without the profiler enabled.

A final process audit observed an unrelated gdsio workload on the host.
Exclusive GPU and storage access was not verified for these runs. The paired
probes provide attribution evidence, but absolute timings and the remaining
large-I/O difference require a quiet rerun before making stable performance
claims. No other workload was stopped.

Local I/O
---------

.. list-table:: 4 KiB GPU read through cuFile, microseconds
   :header-rows: 1
   :widths: 75 25

   * - Path or isolated substitution
     - Latency
   * - KvikIO read
     - 96.8
   * - Unchanged Python read
     - 139.9
   * - Reuse the known allocation's CUDA context
     - 131.0
   * - Bypass observation bookkeeping when no monitor is active
     - 133.0
   * - Forward the worker future for a single task
     - 134.0
   * - Combine those three substitutions
     - 120.5
   * - Reuse a validated array view
     - 135.2
   * - Direct bindings read with a prepared handle and pointer
     - 54.6

The trace confirms two context lookups, two concurrent.futures.Future
constructions, and observation start/finish calls per one-task request.
The observation work occurs even with monitoring disabled. An isolated empty
ThreadPoolExecutor submission plus result retrieval takes about 43 us here.
That includes scheduling and synchronization; it is not 43 us of Python CPU
execution. KvikIO's C++ path resolves the context once and has a single-task
future shortcut.

The combined substitution removes about 19 us, or 14% of this prototype's
latency. The effects overlap and must not be summed. A direct bindings read
has fewer guarantees than the public API and bypasses the worker, validation,
and ownership work; its timing is an I/O baseline, not a compatible replacement.

The 64 MiB cases still incur sixteen 4 MiB native calls. A separate probe
retaining that chunk pattern but issuing it in one worker job reduced the
Python cuFile read from 7.22 to 7.05 ms. It also uses prepared metadata, so this
does not isolate futures alone. The simple small-request substitutions and
using the allocation base plus offsets did not materially improve 64 MiB
reads. The original larger-transfer gap is only partly attributed; it cannot
all be assigned to context lookup or result-object construction.

Implemented changes
-------------------

* Resolve the context once per submission and reuse the handle. Each worker
  still pushes and pops its own thread's CUDA context stack.
* Return immediately from observation setup when no monitor exists, avoiding
  timestamps, locks, and completion-closure allocation.
* Wrap the worker's own future for a single task. When a monitor is active,
  its update runs inside the task before the future becomes ready.

Reproduction
------------

The benchmark script is benchmarks/profile_local.py. It accepts --directory
and --output. Select the prototype through PYTHONPATH; run the reference with
PYTHONPATH unset and --reference. The chunk-loop probe uses
--only original one_worker_chunk_loop --skip-profile. Profiling additionally
requires Yappi; it is not a backend runtime dependency.

``benchmarks/profile-local-*.json`` contain the timings, source paths,
library-loading checks, and full call trees. These measurements predate the
scope cleanup and optimizations. The initial full harness is retained in
``archive/package-wide-prototype-20261105.tar.gz``.
