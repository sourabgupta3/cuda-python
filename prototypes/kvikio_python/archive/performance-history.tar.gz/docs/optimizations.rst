cufile_python performance fixes
===============================

These measurements precede removal of the Python POSIX fallback. They remain
historical evidence, with their original source hashes. The current backend
requires cuFile for host/device I/O and ignores legacy compatibility settings
for routing. The compatibility-mode Python staging cost below no longer applies
to current code. No new performance measurement is claimed for that removal.

The implementation keeps context reuse, the disabled-monitor fast path, and
single-task future forwarding. Multi-chunk I/O now queues at most one Python
job per configured worker and assigns consecutive chunks to each job. Native
chunk sizes, offsets, byte counts, and public future interfaces are unchanged.

Why the costs occurred
----------------------

The original small-request path resolved the CUDA context twice, allocated
statistics bookkeeping even without a monitor, and built both a worker future
and an aggregation future for one task. Those costs are avoidable. A profile
confirms one context lookup and one Future construction after the changes.
Worker context push/pop still restores the previous context. Observed operations
finish their statistics update before the future becomes ready.

The large-read regression exposed a separate dispatch problem. A 64 MiB read
with 4 MiB tasks created sixteen Python jobs/futures. Removing redundant CUDA
queries also removed points where bindings released the GIL: the caller could
enqueue more work before workers started native I/O. Instrumented traces show
the first native read at 182 us without those queries versus 110 us when they
are restored. Trace timings measure scheduling, not production I/O latency.
Restoring redundant queries is not the fix.

Reducing sixteen jobs to four reduces submission work, but interleaved chunk
assignment still performs poorly in the controlled probes. A worker handling
offsets 0, 16, 32, and 48 MiB jumps between ranges. It now handles 0, 4, 8, and
12 MiB; other workers cover the next consecutive ranges. Each native call
still transfers 4 MiB. This improves locality within a worker's file and
buffer range without increasing native request size.

In the same-process assignment probe, interleaved jobs took 4.995 ms per warm
read and consecutive jobs took 3.455 ms. Both used four jobs and sixteen native
calls; only assignment changed. Reducing context push/pop separately did not
help, so that change is not implemented. This demonstrates a dispatch-policy
effect; it does not identify a particular internal libcufile cache or storage
mechanism. The size of the gain varies across fixtures.

The final same-process check used one file, GPU allocation, and pool across six
rotating rounds. Warm-read medians were 3.210 ms for original dispatch,
3.277 ms for regressed dispatch, and 3.215 ms for final dispatch.
Cache-evicted medians were 3.226, 3.310, and 3.211 ms respectively. This isolates
dispatch methods; the complete-backend comparison is below.

Complete-backend measurements
-----------------------------

Latency in microseconds; lower is better. Original means the complete saved
backend before the first three optimizations. Current means cufile_python with
consecutive worker ranges. These are medians of three fresh-process medians
with rotating implementation order, on the same 54-case matrix.

.. list-table:: Selected GPU-buffer cases
   :header-rows: 1
   :widths: 49 17 17 17

   * - Workload
     - Original
     - Current
     - KvikIO
   * - 4 KiB cuFile read, one worker
     - 141.7
     - 128.6
     - 98.9
   * - 4 KiB cuFile write, one worker
     - 127.9
     - 115.7
     - 84.7
   * - 4 KiB raw cuFile read
     - 77.2
     - 69.0
     - 59.4
   * - 4 KiB compatibility read, one worker
     - 100.2
     - 87.9
     - 48.4
   * - 64 MiB cuFile read, one worker
     - 7535.2
     - 7223.2
     - 7187.4
   * - 64 MiB cuFile read, four workers, warm
     - 4859.8
     - 3671.7
     - 5125.2
   * - 64 MiB cuFile read, four workers, file cache evicted
     - 4999.4
     - 5096.1
     - 5023.1

The small cuFile read improves 9.3%, the write 9.5%, and the warm four-worker
large read 24.4%. The matrix's cache-evicted large read remains 1.9% slower than
the original. Those reads occur after the matrix's write workload; they are
not interchangeable with read-only runs. The 4 KiB read still takes 30% longer
than KvikIO, and compatibility-mode small I/O has a larger gap. Python scheduling
and validation remain costs. Native stream I/O does not use this dispatcher
and receives no claimed gain from the dispatch change.

A longer read-only repeat uses six rotating process rounds, each with 300 warm
and 30 cache-evicted reads per implementation. Warm medians are 4.548 ms original,
4.579 ms current, and 4.757 ms KvikIO. Cache-evicted medians are 4.516, 4.585,
and 4.752 ms. Current latency remains 0.7% and 1.5% above original, respectively,
compared with the earlier 4.9%/6.8% regression. The shorter matrix's warm-read
gain does not persist at that size in this longer repeat. No general large-I/O
speedup is claimed. Per-process medians and their spread are retained.

Why the remaining gap differs from KvikIO
-----------------------------------------

KvikIO submits work and consumes futures through Cython into C++, releasing the
GIL around those native operations. cufile_python uses ThreadPoolExecutor,
Python futures/callbacks, and interpreted buffer/context handling. Its blocking
CUDA/cuFile calls also release the GIL, but dispatch and completion still need
Python execution. Native I/O is not serialized under the GIL for its full duration.

The current 4 KiB cuFile read is 29.7 us slower than KvikIO (30%); a raw read,
which bypasses the worker pool, is still 9.7 us slower (16%). Queueing is therefore
not the whole explanation. The GPU compatibility read gap is 39.5 us (82%):
Python also runs the POSIX/staging loop, while KvikIO implements that loop in
C++. Both implementations still perform host/device copies in this mode.
The stream-read-plus-completion gap is 29.4 us (13%); that path does not use
the worker pool, and its remaining cost has not been separately apportioned.

The component profile measures an empty Python task round trip at 42.4 us.
This includes scheduling and waiting; it is not a measured 42.4 us surcharge
over KvikIO and cannot be added to other overlapping costs. Source inspection
and profiling identify the work involved but do not allocate an exact percentage
of the remaining gap to each component. Buffer registration and file/driver setup
are outside the timed matrix operations; statistics monitoring is disabled.

These saved timings precede the compatibility-mode registration correction,
which skips native buffer registration when the wrapper chooses POSIX I/O.
That correction is outside these timed read/write paths; no new timing is claimed.

Method and limits
-----------------

H200 NVL, Linux x86_64, CPython 3.12.3, CUDA bindings 13.4.4, cuFile 1.19,
and KvikIO 26.10.0. Private files are under /mnt/nvme0, an ext4 filesystem on
a four-NVMe RAID0 with 512 KiB chunks. The matrix covers three sizes,
host/device memory, one/four workers, native/compatibility paths, reads,
writes, raw I/O, and stream completion. Task size is 4 MiB, GDS threshold zero,
direct reads off, opportunistic direct writes on, and monitoring disabled.
All implementations receive the same settings and payload checks.

Only private test files are evicted; recorded resident-page counts are zero.
Writes are flushed outside timing. OFF selects cuFile but does not establish
the physical GDS route of each request. Endpoint audits found no other GPU or
gdsio/fio process; the hardware is not reserved. There is no profiler in the
reported throughput comparisons and no statistical confidence interval.
Static assignment can reduce balancing when chunk latencies differ.
These measurements do not establish a general performance advantage.

Evidence and reproduction
-------------------------

* ``benchmarks/contiguous-results.json``: full matrix and backend source hashes.
* ``benchmarks/contiguous-large-read.json``: longer complete-backend repeat.
* ``benchmarks/contiguous-paired.json``: final same-process dispatch comparison.
* ``benchmarks/dispatch-contiguous-probe.json``: assignment-only substitution;
  ``dispatch-context-probe.json`` also checks context push/pop.
* ``benchmarks/dispatch-diagnosis-before.json``: submission/native-call timeline.
* ``benchmarks/contiguous-diagnosis.json``: four jobs and sixteen native reads;
  median submission return 57 us and first native call 99 us in the trace.
* ``benchmarks/optimization-profile.json``: the first three fixes' call counts.
* ``docs/validation/contiguous-*``: tests, applications, logs, and storage details.

Older ``optimization-*`` and ``dispatch-*`` results remain as investigation
history, including the unsuccessful interleaved-worker implementation. Archives
preserve original, regressed, and intermediate backends. README.rst contains
reproduction commands. All implementation changes remain local.

Correctness and migration
-------------------------

* 28 additional tests pass, covering uneven chunk counts, tails, view bounds,
  file offsets, failure draining, context restoration, aliases, and skipping
  native registration under ON/AUTO compatibility selection.
* Selected upstream local suites: 1,001 passed with cuFile selected (12 skipped)
  and 999 with compatibility selected (14 skipped). These overlap. Each run
  deselects seven remote-setting tests outside this subset.
* Ten unchanged upstream application runs pass with matching output hashes.
  Python runs load cufile_python through the explicit alias helper and do not
  load libkvikio.so. All 67 selected declarations still match.
* Canonical imports coexist with original KvikIO. The alias helper is tested
  for idempotence, shared module identity, and refusing an already loaded KvikIO.
* Ruff checks pass. The original cuda.core implementation remains independent.

The earlier registration correction and API audit were validated in
``docs/validation/driver-buffer-*-20261106.*``. The same upstream suite totals
and ten application runs passed again. Performance artifacts retain their
original source hashes rather than being relabeled as fresh measurements.
Current required-cuFile validation is recorded separately in
``docs/validation/required-cufile-*``; those checks replace the old expectation
that compatibility settings can skip native memory registration.
